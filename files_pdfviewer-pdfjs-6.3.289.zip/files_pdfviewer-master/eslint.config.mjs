/**
 * SPDX-FileCopyrightText: 2025 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */

import { recommendedVue2 } from '@nextcloud/eslint-config'

export default [
	...recommendedVue2,
	{
		name: 'files_pdf/config',
		languageOptions: {
			globals: {
				__webpack_public_path__: 'writable',
			},
		},
	},
]
