OC.L10N.register(
    "files_pdfviewer",
    {
    "PDF viewer" : "PDF приказивач",
    "Directly view PDF documents in your Nextcloud. \nAs an added bonus, this app can also display Adobe Illustrator (.ai) files. \nPowered by [pdf.js](https://mozilla.github.io/pdf.js/)" : "Гледајте ваше PDF документе директно у Nextcloud. \nКао додатна могућност, ова апликација такође може да прикаже и Adobe Illustrator (.ai) фајлове. \nПокреће [pdf.js](https://mozilla.github.io/pdf.js/)",
    "Failed to load settings" : "Грешка у дохватању поставки",
    "Failed to save settings" : "Грешка приликом чувања поставки",
    "File upload failed." : "Није успело отпремање фајла.",
    "To view a shared PDF file, the download needs to be allowed for this file share" : "Да бисте видели дељени PDF фајл, потребно је да се за ово дељење допусти преузимање"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
