OC.L10N.register(
    "files_pdfviewer",
    {
    "PDF viewer" : "Visualizzatore PDF",
    "Directly view PDF documents in your Nextcloud. \nAs an added bonus, this app can also display Adobe Illustrator (.ai) files. \nPowered by [pdf.js](https://mozilla.github.io/pdf.js/)" : "Visualizza direttamente i documenti PDF sul tuo Nextcloud. \nCome ulteriore vantaggio, questa app può anche visualizzare i file Adobe Illustrator (.ai). \nOfferto da [pdf.js](https://mozilla.github.io/pdf.js/)",
    "Failed to load settings" : "Caricamento impostazioni non riuscito",
    "Failed to save settings" : "Salvataggio impostazioni non riuscito",
    "File upload failed." : "Caricamento del file non riuscito.",
    "To view a shared PDF file, the download needs to be allowed for this file share" : "Per visualizzare un file PDF condiviso, è necessario che il download sia consentito per questa condivisione di file"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
