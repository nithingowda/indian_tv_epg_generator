OC.L10N.register(
    "files_pdfviewer",
    {
    "PDF viewer" : "PDF-leser",
    "Directly view PDF documents in your Nextcloud. \nAs an added bonus, this app can also display Adobe Illustrator (.ai) files. \nPowered by [pdf.js](https://mozilla.github.io/pdf.js/)" : "Vis PDF dokumenter direkte i Nextcloud. I tillegg til dette, som en ekstra bonus, kan denne appen vise Adobe Illustrator (.ai) filer. Levert av [pdf.js](https://mozilla.github.io/pdf.js/)",
    "Failed to load settings" : "Klarte ikke å laste inn innstillinger",
    "Failed to save settings" : "Klarte ikke å lagre innstillinger",
    "File upload failed." : "Opplasting mislyktes"
},
"nplurals=2; plural=(n != 1);");
