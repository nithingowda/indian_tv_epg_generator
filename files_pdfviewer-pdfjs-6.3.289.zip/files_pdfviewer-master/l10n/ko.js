OC.L10N.register(
    "files_pdfviewer",
    {
    "PDF viewer" : "PDF 뷰어",
    "Directly view PDF documents in your Nextcloud. \nAs an added bonus, this app can also display Adobe Illustrator (.ai) files. \nPowered by [pdf.js](https://mozilla.github.io/pdf.js/)" : "Nextcloud에서 PDF 문서를 직접 볼 수 있습니다. \n추가적으로, 이 앱은 Adobe Illustrator (.ai) 파일도 표시할 수 있습니다. \nPowered by [pdf.js](https://mozilla.github.io/pdf.js/)",
    "Failed to load settings" : "설정을 불러오는 데 실패했습니다",
    "Failed to save settings" : "설정을 저장하는 데 실패했습니다",
    "File upload failed." : "파일 업로드 실패.",
    "To view a shared PDF file, the download needs to be allowed for this file share" : "공유된 PDF 파일을 보려면, 이 파일 공유에 대한 다운로드를 허용해야 합니다"
},
"nplurals=1; plural=0;");
